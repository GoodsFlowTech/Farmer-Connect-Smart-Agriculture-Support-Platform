import { motion, AnimatePresence } from 'motion/react';
import { Sprout, LogIn, Mail, Lock, User as UserIcon } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

export default function Login() {
  const { login, loginWithEmail, registerWithEmail } = useAuth();
  const [error, setError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  
  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setError(null);
    try {
      await login();
    } catch (err: any) {
      handleAuthError(err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    setError(null);
    try {
      if (isSignUp) {
        if (!name.trim()) throw new Error('பெயரை உள்ளிடவும் (Please enter name)');
        await registerWithEmail(email, password, name);
      } else {
        await loginWithEmail(email, password);
      }
    } catch (err: any) {
      handleAuthError(err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAuthError = (err: any) => {
    if (err.code === 'auth/popup-closed-by-user') {
      setError("நுழைவு சாளரம் மூடப்பட்டது. (Login window closed.)");
    } else if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
      setError("மின்னஞ்சல் அல்லது கடவுச்சொல் தவறு. (Invalid email or password)");
    } else if (err.code === 'auth/email-already-in-use') {
      setError("மின்னஞ்சல் ஏற்கனவே பயன்பாட்டில் உள்ளது. (Email already in use)");
    } else if (err.code === 'auth/weak-password') {
      setError("கடவுச்சொல் வலிமையாக இருக்க வேண்டும். (Password is too weak)");
    } else {
      setError("செயல்பாடு தோல்வியடைந்தது. மீண்டும் முயற்சிக்கவும். (Operation failed.)");
    }
    console.error(err);
  };

  return (
    <div className="min-h-screen bg-natural-bg font-sans flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-natural-green rounded-full blur-3xl"></div>
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-natural-olive rounded-full blur-3xl"></div>
      </div>

      <motion.div 
        layout
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl p-8 md:p-12 border border-natural-olive/10 relative z-10"
      >
        <div className="text-center mb-8">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', damping: 12 }}
            className="w-16 h-16 bg-natural-bg rounded-full flex items-center justify-center mx-auto mb-4"
          >
            <Sprout className="w-8 h-8 text-natural-green" />
          </motion.div>
          <h1 className="text-2xl font-black text-natural-green mb-1 tracking-tight">விவசாய நண்பன்</h1>
          <p className="text-natural-olive font-medium italic opacity-70 text-sm">உழவனின் உற்ற தோழன்</p>
        </div>

        <div className="space-y-4">
          <div className="text-center mb-4">
            <h2 className="text-xl font-bold text-gray-800">
              {isSignUp ? 'புதிய உறுப்பினர் பதிவு' : 'வரவேற்கிறோம்!'}
            </h2>
          </div>

          <form onSubmit={handleEmailAuth} className="space-y-4">
            {isSignUp && (
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="உங்கள் பெயர்"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-3 pl-12 pr-4 outline-none focus:border-natural-green/30 transition-all text-sm"
                  required={isSignUp}
                />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="email" 
                placeholder="மின்னஞ்சல்"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-3 pl-12 pr-4 outline-none focus:border-natural-green/30 transition-all text-sm"
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="password" 
                placeholder="கடவுச்சொல்"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-3 pl-12 pr-4 outline-none focus:border-natural-green/30 transition-all text-sm"
                required
              />
            </div>

            {error && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="p-3 bg-red-50 text-red-600 text-[10px] rounded-xl border border-red-100 text-center"
              >
                {error}
              </motion.div>
            )}

            <button
              type="submit"
              disabled={isLoggingIn}
              className="w-full bg-natural-green hover:bg-opacity-90 text-white font-bold py-3 px-6 rounded-2xl shadow-lg transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
            >
              {isLoggingIn ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              ) : (
                <LogIn className="w-5 h-5" />
              )}
              {isSignUp ? 'பதிவு செய்க' : 'நுழைய'}
            </button>
          </form>

          <div className="flex items-center gap-4 my-6">
            <div className="h-px bg-gray-100 flex-1"></div>
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">அல்லது</span>
            <div className="h-px bg-gray-100 flex-1"></div>
          </div>

          <button
            onClick={handleGoogleLogin}
            disabled={isLoggingIn}
            className="w-full bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 font-bold py-3 px-6 rounded-2xl shadow-sm transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
          >
            <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="Google" referrerPolicy="no-referrer" />
            Google மூலம் நுழைய
          </button>

          <div className="text-center mt-6">
            <button 
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError(null);
              }}
              className="text-xs font-bold text-natural-green hover:underline"
            >
              {isSignUp ? 'ஏற்கனவே கணக்கு உள்ளதா? நுழையுங்கள்' : 'புதிய கணக்கை உருவாக்கவா? பதிவு செய்க'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
