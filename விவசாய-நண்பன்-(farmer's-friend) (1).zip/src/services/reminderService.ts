import { 
  collection, 
  addDoc, 
  query, 
  where, 
  onSnapshot, 
  updateDoc, 
  doc, 
  deleteDoc, 
  serverTimestamp,
  orderBy,
  Timestamp
} from 'firebase/firestore';
import { db } from '../lib/firebase';

export interface Reminder {
  id: string;
  userId: string;
  cropName: string;
  taskType: string;
  taskDate: Timestamp;
  status: 'pending' | 'completed';
  notes?: string;
  createdAt: any;
}

export const createReminder = async (userId: string, reminder: Omit<Reminder, 'id' | 'userId' | 'createdAt'>) => {
  return addDoc(collection(db, 'reminders'), {
    ...reminder,
    userId,
    createdAt: serverTimestamp()
  });
};

export const subscribeToReminders = (userId: string, callback: (reminders: Reminder[]) => void) => {
  const q = query(
    collection(db, 'reminders'), 
    where('userId', '==', userId),
    orderBy('taskDate', 'asc')
  );

  return onSnapshot(q, (snapshot) => {
    const reminders = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Reminder[];
    callback(reminders);
  });
};

export const updateReminderStatus = async (reminderId: string, status: 'pending' | 'completed') => {
  const reminderRef = doc(db, 'reminders', reminderId);
  return updateDoc(reminderRef, { status });
};

export const deleteReminder = async (reminderId: string) => {
  const reminderRef = doc(db, 'reminders', reminderId);
  return deleteDoc(reminderRef);
};
