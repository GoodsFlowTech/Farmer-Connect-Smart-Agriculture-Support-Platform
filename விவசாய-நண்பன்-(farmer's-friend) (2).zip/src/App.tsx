/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useEffect } from 'react';
import { Search, Upload, Sprout, ThermometerSun, Droplets, Calendar, IndianRupee, TrendingUp, AlertTriangle, Loader2, Mic, MicOff, Calculator, LogOut, User as UserIcon, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import ReactMarkdown from 'react-markdown';
import { MONTHS, CROP_DATA, type Crop } from './data/crops';
import { getTamilDate } from './data/calendar';
import TamilCalendarView from './components/TamilCalendarView';
import YieldCalculator from './components/YieldCalculator';
import MarketPrices from './components/MarketPrices';
import CropDetailModal from './components/CropDetailModal';
import Reminders from './components/Reminders';
import { analyzeCropDisease } from './lib/gemini';
import { CROP_DETAILS, CropDetail } from './data/cropDetails';
import { subscribeToReminders, Reminder as ReminderType } from './services/reminderService';
import ChatBot from './components/ChatBot';
import { useAuth } from './context/AuthContext';
import Login from './components/Login';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const { user, loading, logout } = useAuth();
  const [selectedMonth, setSelectedMonth] = useState<string>("ஜனவரி");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [prediction, setPrediction] = useState<any>(null);
  const [searchResults, setSearchResults] = useState<Crop[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [showLoginSuccess, setShowLoginSuccess] = useState(false);
  const [showTamilCalendar, setShowTamilCalendar] = useState(false);
  const [showYieldCalculator, setShowYieldCalculator] = useState(false);
  const [activeTab, setActiveTab] = useState<'recommendations' | 'market'>('recommendations');
  const [selectedDetailedCrop, setSelectedDetailedCrop] = useState<CropDetail | null>(null);
  const [showReminders, setShowReminders] = useState(false);
  const [remindersCount, setRemindersCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const tamilDateInfo = getTamilDate(new Date());

  useEffect(() => {
    if (user) {
      setShowLoginSuccess(true);
      const timer = setTimeout(() => setShowLoginSuccess(false), 3000);
      
      const unsubscribe = subscribeToReminders(user.uid, (data) => {
        const pendingCount = data.filter(r => r.status === 'pending').length;
        setRemindersCount(pendingCount);
        
        // Simple check for due reminders to pulse
        const now = new Date();
        data.forEach(rem => {
          if (rem.status === 'pending' && rem.taskDate.toDate() <= now) {
             // You could trigger a local notify here if and only if it just turned due
          }
        });
      });

      return () => {
        clearTimeout(timer);
        unsubscribe();
      };
    }
  }, [user]);

  useEffect(() => {
    // Setup Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'ta-IN'; // Tamil support

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        setIsListening(false);
        // Trigger search functionality for months or crops automatically
        executeSearch(transcript);
      };

      recognitionRef.current.onerror = () => setIsListening(false);
      recognitionRef.current.onend = () => setIsListening(false);
    }
  }, []);

  const toggleVoiceSearch = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      setIsListening(true);
      recognitionRef.current?.start();
    }
  };

  useEffect(() => {
    setSearchResults(CROP_DATA[selectedMonth] || []);
    setSearchQuery(`${selectedMonth} மாதம் - பரிந்துரை`);
  }, [selectedMonth]);

  const executeSearch = (queryText: string) => {
    const query = queryText.trim();
    if (!query) return;

    if (MONTHS.some(m => query.includes(m))) {
      const foundMonth = MONTHS.find(m => query.includes(m))!;
      setSelectedMonth(foundMonth);
      setSearchResults(CROP_DATA[foundMonth] || []);
    } else {
      const results: Crop[] = [];
      Object.values(CROP_DATA).forEach(monthCrops => {
        monthCrops.forEach(crop => {
          if (crop.பெயர்.includes(query) || crop.வகை.includes(query)) {
            if (!results.find(r => r.id === crop.id)) {
              results.push(crop);
            }
          }
        });
      });
      setSearchResults(results);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(searchQuery);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    setPrediction(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64 = (event.target?.result as string).split(',')[1];
      const result = await analyzeCropDisease(base64, file.type);
      setPrediction(result);
      setIsAnalyzing(false);
    };
    reader.readAsDataURL(file);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-natural-bg flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-natural-green/30 border-t-natural-green rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <div className="min-h-screen bg-natural-bg font-sans flex flex-col relative overflow-x-hidden">
      {/* Login Success Notification */}
      <AnimatePresence>
        {showLoginSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 20 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] bg-white text-natural-green px-6 py-3 rounded-2xl shadow-xl border-b-4 border-natural-green flex items-center gap-3 font-bold"
          >
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              ✅
            </div>
            வெற்றிகரமாக புகுபதிவு செய்யப்பட்டது! (Login Successful)
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-dot-pattern"></div>

      {/* Header */}
      <header className="bg-natural-green text-white px-8 py-4 flex items-center justify-between shadow-lg z-10 sticky top-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-natural-cream rounded-full flex items-center justify-center">
            <Sprout className="w-6 h-6 text-natural-green" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tight">விவசாய நண்பன்</h1>
            <span className="text-[10px] md:text-xs font-normal block opacity-80 italic tracking-wider">உழவனின் உற்ற தோழன்</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {/* Tamil Calendar Info */}
          <button 
            onClick={() => setShowTamilCalendar(true)}
            className="hidden lg:flex items-center gap-3 bg-natural-cream/20 px-4 py-2 rounded-2xl border border-white/10 text-white hover:bg-white/20 transition-all text-left"
          >
            <Calendar className="w-4 h-4 opacity-70" />
            <div className="text-[10px] leading-tight">
              <p className="opacity-70 uppercase tracking-tighter">தமிழ் வருடம்: {tamilDateInfo.name}</p>
              <p className="font-bold">{tamilDateInfo.month}</p>
            </div>
          </button>

          <button 
            onClick={() => setShowYieldCalculator(true)}
            className="flex items-center gap-3 bg-natural-green border border-white/20 px-4 py-2 rounded-2xl text-white hover:bg-natural-olive transition-all shadow-lg"
          >
            <Calculator className="w-5 h-5" />
            <span className="hidden sm:inline text-xs font-bold uppercase tracking-widest">மகசூல் கணக்கீடு</span>
          </button>

          <button 
            onClick={() => setShowReminders(true)}
            className="p-2.5 bg-white/10 hover:bg-natural-green/20 text-white rounded-xl transition-all border border-white/10 hover:border-natural-green/30 relative"
            title="நினைவூட்டல்கள்"
          >
            <Bell className="w-5 h-5" />
            {remindersCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                {remindersCount}
              </span>
            )}
          </button>

          <div className="hidden md:flex items-center gap-4 bg-white/10 px-4 py-2 rounded-2xl border border-white/10">
            <div className="text-right text-[10px] uppercase tracking-widest leading-tight">
              <p className="opacity-70">வரவேற்கிறோம்</p>
              <p className="font-bold truncate max-w-[150px]">{user.displayName || 'விவசாயி'}</p>
            </div>
            {user.photoURL ? (
              <img src={user.photoURL} alt="Profile" className="w-8 h-8 rounded-full border border-white/20" referrerPolicy="no-referrer" />
            ) : (
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center border border-white/20">
                <UserIcon className="w-4 h-4" />
              </div>
            )}
          </div>
          <button 
            onClick={() => logout()}
            className="p-2.5 bg-white/10 hover:bg-red-500/20 text-white rounded-xl transition-all border border-white/10 hover:border-red-500/30 group"
            title="வெளியேற"
          >
            <LogOut className="w-5 h-5 group-hover:scale-110 transition-transform" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 relative z-10 max-w-7xl mx-auto w-full">
        {/* Left Column (4/12) */}
        <div className="md:col-span-4 flex flex-col gap-8">
          <section className="bg-white p-6 rounded-3xl shadow-sm border border-natural-olive/10">
            <h3 className="text-lg font-bold text-natural-green mb-4 flex items-center gap-2">
              🗓️ பயிரிட வேண்டிய மாதம்
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {MONTHS.map((m) => (
                <button
                  key={m}
                  onClick={() => setSelectedMonth(m)}
                  className={cn(
                    "btn-month",
                    selectedMonth === m && "active"
                  )}
                >
                  {m}
                </button>
              ))}
            </div>

            {/* Tamil Date Display below the grid */}
            <div className="mt-8 pt-6 border-t border-natural-olive/10">
              <div className="bg-natural-bg/40 p-5 rounded-[2rem] border border-natural-olive/5 flex flex-col items-center text-center relative overflow-hidden group">
                {/* Decorative background element */}
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-natural-green/5 rounded-full blur-xl group-hover:bg-natural-green/10 transition-all"></div>
                
                <p className="text-[10px] font-bold text-natural-olive/50 uppercase tracking-[0.2em] mb-2 leading-none">இன்றைய தமிழ் தேதி</p>
                <div className="flex flex-col items-center">
                  <p className="text-xl font-black text-natural-green tracking-tight mb-1">{tamilDateInfo.name} வருடம்</p>
                  <div className="flex items-center gap-2">
                    <div className="bg-natural-green px-3 py-1 rounded-full shadow-sm">
                      <p className="text-xs font-bold text-white tracking-wide">{tamilDateInfo.month}</p>
                    </div>
                    <div className="w-1 h-1 bg-natural-olive/20 rounded-full"></div>
                    <p className="text-lg font-black text-gray-700">{tamilDateInfo.day}</p>
                  </div>
                </div>
                
                <button 
                  onClick={() => setShowTamilCalendar(true)}
                  className="mt-4 text-[10px] font-bold text-natural-olive/60 hover:text-natural-green transition-colors uppercase tracking-widest flex items-center gap-1.5"
                >
                  முழு நாட்காட்டி <TrendingUp className="w-2.5 h-2.5 rotate-90" />
                </button>
              </div>
            </div>
          </section>

          <section className="bg-natural-olive text-natural-bg p-8 rounded-3xl shadow-md flex-1 flex flex-col">
            <div className="mb-8">
              <h3 className="text-2xl font-bold mb-3 flex items-center gap-3 outline-none">
                🔍 நோய் ஆய்வு
              </h3>
              <p className="text-sm opacity-80 leading-relaxed">
                உங்கள் பயிரில் நோய் அறிகுறிகள் உள்ளதா? புகைப்படம் பதிவேற்றி உடனே தீர்வு பெறுங்கள்.
              </p>
            </div>

            <input 
              type="file" 
              ref={fileInputRef}
              onChange={handleImageUpload}
              accept="image/*"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isAnalyzing}
              className={cn(
                "border-2 border-dashed border-natural-bg/40 rounded-2xl p-8 text-center hover:bg-white/5 cursor-pointer transition-all flex flex-col items-center justify-center gap-2",
                isAnalyzing && "animate-pulse bg-white/10"
              )}
            >
              {isAnalyzing ? (
                <Loader2 className="w-10 h-10 animate-spin opacity-50" />
              ) : (
                <div className="text-center">
                  <span className="text-4xl block mb-2">📸</span>
                  <p className="text-xs font-medium uppercase tracking-widest">இங்கே பதிவேற்றவும்</p>
                </div>
              )}
            </button>

            {/* AI Result Overlay for left column */}
            <AnimatePresence>
              {prediction && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white/10 p-5 rounded-2xl mt-6 border border-white/10 backdrop-blur-sm"
                >
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-4 h-4 text-orange-300" />
                    <p className="text-[10px] uppercase tracking-wider opacity-60">கடைசி ஆய்வு முடிவு</p>
                  </div>
                  <p className="text-sm font-bold text-natural-cream mb-1">{prediction.நோய்}</p>
                  <p className="text-xs opacity-70 line-clamp-2">{prediction.அறிகுறி}</p>
                  <div className="mt-4 pt-3 border-t border-white/10">
                     <p className="text-[10px] uppercase tracking-wider opacity-60 mb-2">தீர்வு முறை</p>
                     <div className="prose prose-invert prose-sm text-xs opacity-80">
                        <ReactMarkdown>{prediction.தீர்வு_முறை}</ReactMarkdown>
                     </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        </div>

        {/* Right Column (8/12) */}
        <div className="md:col-span-8 flex flex-col gap-8">
          {/* Tabs Section */}
          <div className="flex gap-4 p-1 bg-white/50 backdrop-blur-md rounded-3xl border border-natural-olive/10 w-fit">
            <button 
              onClick={() => setActiveTab('recommendations')}
              className={cn(
                "px-6 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all",
                activeTab === 'recommendations' ? "bg-natural-green text-white shadow-lg" : "text-natural-olive hover:bg-natural-bg"
              )}
            >
              பயிர் பரிந்துரை
            </button>
            <button 
              onClick={() => setActiveTab('market')}
              className={cn(
                "px-6 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all",
                activeTab === 'market' ? "bg-natural-green text-white shadow-lg" : "text-natural-olive hover:bg-natural-bg"
              )}
            >
              சந்தை நிலவரம்
            </button>
          </div>

          <AnimatePresence mode="wait">
            {activeTab === 'market' ? (
              <motion.div
                key="market-tab"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
              >
                <MarketPrices />
              </motion.div>
            ) : (
              <motion.div
                key="recommendations-tab"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="flex flex-col gap-8"
              >
                {/* Search Header */}
          <section className="bg-white p-2 md:p-3 rounded-full shadow-sm flex items-center gap-4 border border-natural-olive/10 px-6 pr-2">
            <Search className="text-natural-green w-5 h-5 hidden sm:block" />
            <form onSubmit={handleSearch} className="flex-1 flex gap-2 items-center">
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="பயிர் அல்லது மாதம் தேடுக..." 
                className="bg-transparent flex-1 outline-none text-sm font-medium"
              />
              <button
                type="button"
                onClick={toggleVoiceSearch}
                className={cn(
                  "p-2 rounded-full transition-all",
                  isListening ? "bg-red-100 text-red-500 animate-pulse" : "bg-natural-bg text-natural-green hover:bg-natural-green hover:text-white"
                )}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
              <button 
                type="submit"
                className="bg-natural-green text-white px-8 py-3 rounded-full text-sm font-bold shadow-md hover:bg-opacity-95 transition-all"
              >
                தேடுக
              </button>
            </form>
          </section>

          {/* Table Container */}
          <section className="bg-white rounded-[2rem] shadow-sm border border-natural-olive/10 flex-1 flex flex-col overflow-hidden">
            <div className="p-8 border-b border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <h3 className="font-bold text-natural-green text-xl">✅ {selectedMonth} மாதத்திற்கான பயிர் பரிந்துரை</h3>
              <span className="px-4 py-1.5 bg-green-50 text-green-700 text-[10px] font-bold rounded-full uppercase tracking-tighter border border-green-100">
                ஏற்ற பருவம்
              </span>
            </div>
            
            <div className="flex-1 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead className="bg-natural-bg text-natural-olive text-[10px] font-bold uppercase tracking-widest border-b border-gray-100">
                  <tr>
                    <th className="px-8 py-5">பெயர்</th>
                    <th className="px-8 py-5">வகை</th>
                    <th className="px-8 py-5 text-center">நீர் அளவு</th>
                    <th className="px-8 py-5">மண் வகை</th>
                    <th className="px-8 py-5">முதலீடு / லாபம்</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  <AnimatePresence mode="popLayout">
                    {searchResults.length > 0 ? (
                      searchResults.map((crop, idx) => (
                        <motion.tr
                          key={crop.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.05 }}
                          className="hover:bg-green-50/30 transition-colors group"
                        >
                          <td className="px-8 py-6">
                            <button 
                              onClick={() => {
                                const detail = CROP_DETAILS[crop.பெயர்] || CROP_DETAILS[crop.பெயர்.split(' ')[0]];
                                if (detail) {
                                  setSelectedDetailedCrop(detail);
                                } else {
                                  // Generic feedback if detail not found
                                  alert("தகவல் விரைவில் வரும்...");
                                }
                              }}
                              className="font-bold text-gray-800 group-hover:text-natural-green transition-colors text-left"
                            >
                              {crop.பெயர்}
                            </button>
                          </td>
                          <td className="px-8 py-6 text-sm text-gray-500">{crop.வகை}</td>
                          <td className="px-8 py-6">
                            <div className="flex justify-center gap-1.5">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <div 
                                  key={i} 
                                  className={cn(
                                    "w-2.5 h-2.5 rounded-full",
                                    i < (crop.நீர் === 'அதிகம்' ? 4 : crop.நீர் === 'மிதமான' ? 3 : 2) 
                                      ? "bg-blue-400" 
                                      : "bg-gray-200"
                                  )}
                                />
                              ))}
                            </div>
                          </td>
                          <td className="px-8 py-6 text-xs font-medium text-natural-olive italic">{crop.மண்}</td>
                          <td className="px-8 py-6">
                            <p className="text-[10px] font-medium text-gray-400 mb-0.5">{crop.முதலீடு}</p>
                            <p className="text-sm font-bold text-green-600">{crop.லாபம்}</p>
                          </td>
                        </motion.tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="px-8 py-16 text-center text-gray-400 italic">
                          தேடப்பட்ட தகவல்கள் எதுவும் இல்லை.
                        </td>
                      </tr>
                    )}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>

            {/* Bottom Warning Alert */}
            <div className="mt-auto p-6 bg-orange-50 border-t border-orange-100 flex items-center gap-5">
              <span className="text-3xl filter drop-shadow-sm" aria-hidden="true">⚠️</span>
              <div className="text-xs text-orange-900">
                <p className="font-bold uppercase tracking-tight mb-1">வானிலை எச்சரிக்கை</p>
                <p className="opacity-80">அடுத்த 48 மணி நேரத்தில் உங்கள் பகுதியில் மிதமான மழைக்கு வாய்ப்பு உள்ளது. அறுவடை செய்த பயிர்களைப் பாதுகாக்கவும்.</p>
              </div>
            </div>
          </section>
        </motion.div>
      )}
    </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto bg-white/50 border-t border-natural-olive/10 px-8 py-4 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-bold text-natural-olive uppercase tracking-widest">
        <p>© 2026 விவசாய நண்பன் - தொழில்நுட்பம் மூலம் விவசாயம்</p>
        <div className="flex gap-6">
          <span className="hover:text-natural-green cursor-pointer transition-colors">சந்தை நிலவரம்</span>
          <span className="hover:text-natural-green cursor-pointer transition-colors">அரசு மானியங்கள்</span>
          <span className="hover:text-natural-green cursor-pointer transition-colors">உரம் மேலாண்மை</span>
        </div>
      </footer>

      {/* Floating Chat Bot */}
      <ChatBot />

      <AnimatePresence>
        {selectedDetailedCrop && (
          <CropDetailModal 
            crop={selectedDetailedCrop} 
            onClose={() => setSelectedDetailedCrop(null)} 
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showTamilCalendar && (
          <TamilCalendarView onClose={() => setShowTamilCalendar(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showYieldCalculator && (
          <YieldCalculator onClose={() => setShowYieldCalculator(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showReminders && (
          <Reminders onClose={() => setShowReminders(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
